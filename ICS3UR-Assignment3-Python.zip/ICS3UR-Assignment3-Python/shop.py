#!/usr/bin/env python3

# Created by Gabriel A
# Created on Dec 2020
# This program calculates the total price of an item in a shop
# A PS5 controller costs 90 CAD


def main():
    # input
    units = int(input("Desired amount of PS5 Controllers: "))
    integer = units * 90

    # process
    if integer >= 1000:
        integer = integer - (integer * 0.10)

    total = integer * 1.13

    # output
    print("")
    print("TOTAL FOR {0} PS5 CONTROLLERS: ${1:,.2f}." .format(units, total))


if __name__ == "__main__":
    main()
